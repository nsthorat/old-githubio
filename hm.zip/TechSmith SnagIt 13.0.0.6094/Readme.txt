Installation notes:

1. Install.
2. Register with the serial provided by the keygen.